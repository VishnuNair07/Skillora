<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
</head>
<body>
    
 <!-- <div class="row text-center">
	<h2><b>CONTACT US</b></h2><br><br>
	<center>
	<div class="card" style="width: 30rem;">
  <div class="card-body border-info">
   
   <form>
  <div class="input-box">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="input-box">
    <label for="exampleInputPassword1">message</label>
    <input type="password" class="form-control"  placeholder="enter your message">
  </div>
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
  </div>
</div></center>
</div> -->
 
 
  <div class="contact" id="contact">
	<h2>CONTACT</h2>
    <div class="content2">
      <div class="left-side">
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">9123421332</div>
          <div class="text-two">8098231312</div>
        </div>
        <div class="email details">
          <div class="topic">Email</div>
          <div class="text-one">codingphp@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>
        <p>If you have any work from me or any types of quries related to my tutorial, you can send me message from here. It's my pleasure to help you.</p>
      <form action="#">
        <div class="input-box">
			<label for="exampleInputEmail1">Email address : </label><br>
			<input type="email" class="form-control" aria-describedby="emailHelp" placeholder="Enter email">
        </div>
        <div class="input-box message-box">
			<label for="exampleInputPassword1">message</label><br>
			<textarea name="" id="" cols="40" rows="10" class="form-control" placeholder="Enter the message here.. "></textarea>
        </div>

		<button type="submit" class="btn btn-primary">Submit</button>

      </form>
  </div>
    </div>
  </div>



</body>
</html>