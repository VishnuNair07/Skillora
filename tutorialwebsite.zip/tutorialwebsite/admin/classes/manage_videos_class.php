<?php 

class manage_videos_class
 {


 	public $host="localhost";
 	public $username="root";
 	public $pass="";
 	public $db_name="tutorialwebsite";
 	public $conn;
 	public $videos_list;
 	

 	public function __construct()
 	{
 		$this->conn=new mysqli($this->host,$this->username,$this->pass,$this->db_name);
 		if ($this->conn->connect_errno)
 		 {
 			die("connection failed");
 		}
 	}

 	public function display_videos()
 	{
 		$query="select * from video_info";
 		$result=$this->conn->query($query);
 		
 		while($row=$result->fetch_array(MYSQLI_ASSOC))
 		{
 			$this->videos_list[]=$row;
 		}
 		return $this->videos_list;
 	}
}

 ?>