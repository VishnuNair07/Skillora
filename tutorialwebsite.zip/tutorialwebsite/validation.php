 <?php 

session_start();

$login = false;
$con=mysqli_connect('localhost','root');

// if ($con) 
//   {
// 		echo "connection successful";
//   }
// else
// 	{
// 		echo "no connection";
// 	}

 mysqli_select_db($con,'tutorialwebsite');
 $name=$_POST['name'];
 $pass=$_POST['password'];
//  $email=$_POST['email'];

//  $q="select * from login where username='$name' && password='$pass'";

//  $result=mysqli_query($con,$q);
//  $res=mysqli_fetch_assoc($result);
//  $num=mysqli_num_rows($result);

 $q="select * from login where username='$name'";

 $result=mysqli_query($con,$q);
 $num=mysqli_num_rows($result);
 if ($num==1)
  {
	while($row=mysqli_fetch_assoc($result)){
		if(password_verify($pass , $row['password'])){
			$login = true;
			session_start();
			if ($res['username']=='admin') 
			{
				header("location:admin/admin_main.php");
				
			}
		
		else
			{
		   $_SESSION['username']=$name;
		   header('location:index.php');
		   }
		}
		 
 else
 {
	 $_SESSION['error']="error";
 	header('location:login.php');

 }
	}
  }
 

  

 ?>