<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Linking CSS -->
    <link rel="stylesheet" href="style.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <!-- Main Title Icon -->
    <link rel="icon" type="image/gif/png" href="./images/Main Tab Image-Logo.png">
    <title>Skillora - Login</title>
    <link href="https://fonts.googleapis.com/css?family=Aleo" rel="stylesheet">

	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	<!----Linking google fonts-->
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!----font-awsome start-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    	<!----css file link-->

<!----favicon setting-->
<link rel="shortcut icon" type="text/css" href="img/mylogo.png">

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>

<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				

				<h1 style="color: #5c9f24;margin-top: 10px;" id="myhead">Skillora</h1>
			</div>
		
		</div>
	</nav>
    <div class="containter2">
        <div class="bluebg">
            <div class="box signin">
                <!-- Sign In Button -->
                <h2>Already Have an Account?</h2>
                <button class="signinbtn">Sign In
                </button>
            </div>
            <div class="box signup">
                <!-- Sign Up Button -->
                <h2>Don't Have an Account?</h2>
                <button class="signupbtn">Sign Up</button>
            </div>
        </div>
        <div class="formBx">
            <!------------ Slider ------------->
            <div class="form signinForm">
                <!-- Sign In Form -->
                <form method="POST" action="validation.php" onsubmit="return validation()">
                    <i class='bx bx-log-in signinimage'></i>
                    <h3>Sign In</h3>
                    <input type="text" name="name" id="username" placeholder=" Username">
                    <input type="password" id="password" name="password" placeholder=" Password">
                    <span toggle="#password" class="fa fa-fw fa-eye field-icon fa-eye-slash toggle-password"></span>
                    <span id="perror"><?php 
								if(isset($_SESSION['error']))
								{
									echo "wrong username or password";
								} 
								else{ echo " ";} 
								?>
									

								</span>
                    <input type="submit" value="Login" id="btn-login" type="submit">
                    <!-- <a href="#" class="forgot">Forgot Password?</a> -->
                </form>
            </div>
            <div class="form signupForm">
                <!-- Sign Up Form -->
                <form method="POST" action="registration.php">
                    <i class='bx bxs-user signupimage'></i>
                    <h3>Sign Up</h3>
                    <input type="text" name="name" placeholder=" Username">
                    <input type="text" name="email" placeholder=" Email Address">
                    <input type="password" name="password" id="pwd" placeholder=" Password">
                    <input type="password" name="confirm_password" id="cpwd" placeholder=" Confirm Password">
                    <div id="errorlabel"></div>
                    <input type="submit" id="btn-login" type="submit" value="Register">
                </form>
            </div>
        </div>
    </div>
    <script src="app.js"></script>
    <script type="text/javascript">
	
function validation() {
	var username=document.getElementById('username').value;
	var password=document.getElementById('password').value;

	if ((username=="") ||( password==""))
	 {
	 	document.getElementById('perror').innerHTML=`<p style="color:red;">please fill the details</p>`;
	 	return false;
	 }
}


function clear() {
	document.getElementById('perror').innerHTML="ksdfisdhfg";
}

$(".toggle-password").click(function() {

$(this).toggleClass("fa-eye fa-eye-slash");
var input = $($(this).attr("toggle"));
if (input.attr("type") === "password") {
  input.attr("type", "text");
  $(this).addClass('fa-eye').removeClass('fa-eye-slash');
} else {
  input.attr("type", "password");
  $(this).addClass('fa-eye-slash').removeClass('fa-eye');
}
});

</script>
<script type="text/javascript">
	
    $(document).ready(function(){

$('#cpwd').keyup(function(){
	var pwd=$('#pwd').val();
	var cpwd=$('#cpwd').val();
	if (pwd!=cpwd) 
	{
		$('#errorlabel').html('**password are not matched');
		$('#errorlabel').css('color','red');
		return false;
	}
	else
	{
		$('#errorlabel').html('');
		return true;
	}
});

});


</script>
         <!---confirm password validation end------->


<script src="js/jquery.ripples-min.js" type="text/javascript"></script>
<script src="js/typed.min.js" type="text/javascript"></script>
</body>

</html>